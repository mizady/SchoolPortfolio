package com.example.inventoryviewapp.helpers;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryviewapp.R;
import com.example.inventoryviewapp.UpdateInventoryItemActivity;
import com.example.inventoryviewapp.entities.InventoryItem;

import java.util.List;

public class InventoryItemAdapter extends RecyclerView.Adapter<InventoryItemAdapter.ViewHolder> {

    private List<InventoryItem> inventoryItems;
    private Context context;

    public InventoryItemAdapter(List<InventoryItem> inventoryItems, Context context) {
        this.inventoryItems = inventoryItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_data_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        InventoryItem inventoryItem = inventoryItems.get(position);
        holder.titleTextView.setText(inventoryItem.getTitle());
        holder.descriptionTextView.setText(inventoryItem.getDescription());
        holder.itemQuantityTextView.setText((inventoryItem.getQuantity()));

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int itemId = inventoryItems.get(position).getId();
                DatabaseHelper dbHelper = new DatabaseHelper(context);
                dbHelper.deleteItem(itemId);
                inventoryItems.remove(position);
                notifyDataSetChanged();
            }
        });

        holder.updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateInventoryItemActivity.class);
                intent.putExtra("ITEM_ID", inventoryItems.get(position).getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, descriptionTextView, itemQuantityTextView;
        Button deleteButton, updateButton;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.itemName);
            descriptionTextView = itemView.findViewById(R.id.itemDescription);
            itemQuantityTextView = itemView.findViewById(R.id.itemQuantity);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            updateButton = itemView.findViewById(R.id.updateButton);
        }
    }
}
