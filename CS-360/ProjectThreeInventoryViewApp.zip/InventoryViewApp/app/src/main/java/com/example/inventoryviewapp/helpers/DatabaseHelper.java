package com.example.inventoryviewapp.helpers;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.inventoryviewapp.entities.InventoryItem;

import org.mindrot.jbcrypt.BCrypt;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "MyDB.db";
    public static final String USERS_TABLE_NAME = "users";
    public static final String USERS_COLUMN_ID = "id";
    public static final String USERS_COLUMN_USERNAME = "username";
    public static final String USERS_COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE_NUMBER = "phone_number";

    public static final String INVENTORY_TABLE_NAME = "inventory";
    public static final String INVENTORY_COLUMN_ID = "id";
    public static final String INVENTORY_COLUMN_NAME = "name";
    public static final String INVENTORY_COLUMN_QUANTITY = "quantity";
    public static final String INVENTORY_COLUMN_DESCRIPTION = "category";
    public static final String INVENTORY_COLUMN_LOCATION = "location";
    public static final String INVENTORY_COLUMN_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_USERS_TABLE = "CREATE TABLE " + USERS_TABLE_NAME + " (" +
                USERS_COLUMN_ID + " INTEGER PRIMARY KEY, " +
                USERS_COLUMN_USERNAME + " TEXT, " +
                USERS_COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + INVENTORY_TABLE_NAME + " (" +
                INVENTORY_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                INVENTORY_COLUMN_NAME + " TEXT, " +
                INVENTORY_COLUMN_QUANTITY + " INTEGER, " +
                INVENTORY_COLUMN_DESCRIPTION + " TEXT, " +
                INVENTORY_COLUMN_CREATED_AT + " TEXT)";
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE_NAME);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERS_COLUMN_USERNAME, username);
        contentValues.put(USERS_COLUMN_PASSWORD, hashPassword(password));

        long result = db.insert(USERS_TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public boolean verifyUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USERS_TABLE_NAME + " WHERE " + USERS_COLUMN_USERNAME + "=?", new String[]{username});

        if (cursor.moveToFirst()) {
            @SuppressLint("Range") String storedHashedPassword = cursor.getString(cursor.getColumnIndex(USERS_COLUMN_PASSWORD));
            cursor.close();
            return checkPassword(password, storedHashedPassword);
        }

        cursor.close();
        return false;
    }

    public void updateUserPhoneNumber(int userId, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);

        db.update(USERS_TABLE_NAME, values, USERS_COLUMN_ID + "=?", new String[]{String.valueOf(userId)});
    }

    public String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    private boolean checkPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }

    // Inventory Item Related Methods

    public long addItem(String name, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(INVENTORY_COLUMN_NAME, name);
        contentValues.put(INVENTORY_COLUMN_QUANTITY, quantity);
        contentValues.put(INVENTORY_COLUMN_DESCRIPTION, description);
        contentValues.put(INVENTORY_COLUMN_CREATED_AT, getCurrentUtcDateTime());
        return db.insert(INVENTORY_TABLE_NAME, null, contentValues);
    }

    public InventoryItem getItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + INVENTORY_TABLE_NAME + " WHERE " + INVENTORY_COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") int itemId = cursor.getInt(cursor.getColumnIndex(INVENTORY_COLUMN_ID));
            @SuppressLint("Range") String itemName = cursor.getString(cursor.getColumnIndex(INVENTORY_COLUMN_NAME));
            @SuppressLint("Range") String itemDescription = cursor.getString(cursor.getColumnIndex(INVENTORY_COLUMN_DESCRIPTION));
            @SuppressLint("Range") int itemQuantity = cursor.getInt(cursor.getColumnIndex(INVENTORY_COLUMN_QUANTITY));
            cursor.close();

            return new InventoryItem(itemId, itemName, itemDescription, itemQuantity);
        } else {
            return null;
        }
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + INVENTORY_TABLE_NAME, null);
    }

    public boolean updateItem(int id, String name, int quantity, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(INVENTORY_COLUMN_NAME, name);
        contentValues.put(INVENTORY_COLUMN_QUANTITY, quantity);
        contentValues.put(INVENTORY_COLUMN_DESCRIPTION, description);
        int rowsAffected = db.update(INVENTORY_TABLE_NAME, contentValues, INVENTORY_COLUMN_ID + "=?", new String[]{String.valueOf(id)});

        return rowsAffected > 0;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(INVENTORY_TABLE_NAME, INVENTORY_COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return rowsAffected > 0;
    }

    private String getCurrentUtcDateTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return dateFormat.format(calendar.getTime());
    }
}
