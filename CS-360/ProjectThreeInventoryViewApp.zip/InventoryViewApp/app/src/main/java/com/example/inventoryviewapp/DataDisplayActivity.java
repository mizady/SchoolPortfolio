package com.example.inventoryviewapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import com.example.inventoryviewapp.entities.InventoryItem;
import com.example.inventoryviewapp.helpers.DatabaseHelper;
import com.example.inventoryviewapp.helpers.InventoryItemAdapter;

import java.util.List;
import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private RecyclerView dataRecyclerView;
    private InventoryItemAdapter inventoryItemAdapter;
    private List<InventoryItem> dataList;
    private static final int PERMISSION_REQUEST_SEND_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dataList = new ArrayList<>();

        dataList.add(new InventoryItem("Test entry 1", "Entry value 1", 12));

        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        dataRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        inventoryItemAdapter = new InventoryItemAdapter(dataList, this);
        dataRecyclerView.setAdapter(inventoryItemAdapter);

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    private void loadItems() {
        Cursor cursor = dbHelper.getAllItems();
        dataList = new ArrayList<>();

        while (cursor.moveToNext()) {
            @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(DatabaseHelper.INVENTORY_COLUMN_NAME));
            @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex(DatabaseHelper.INVENTORY_COLUMN_DESCRIPTION));
            @SuppressLint("Range") int quantity = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.INVENTORY_COLUMN_QUANTITY));

            InventoryItem item = new InventoryItem(title, description, quantity);
            dataList.add(item);
        }

        cursor.close();
        inventoryItemAdapter = new InventoryItemAdapter(dataList, this);
        dataRecyclerView.setAdapter(inventoryItemAdapter);
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can send SMS now
            } else {
                // Permission denied, the app should continue to function but not send SMS
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendLowInventorySms(String phoneNumber, String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Item '" + itemName + "' is out of stock!";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } else {
            requestSmsPermission();
        }
    }



}