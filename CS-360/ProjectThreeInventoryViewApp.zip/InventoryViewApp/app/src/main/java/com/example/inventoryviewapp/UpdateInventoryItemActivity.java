package com.example.inventoryviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.inventoryviewapp.entities.InventoryItem;
import com.example.inventoryviewapp.helpers.DatabaseHelper;

public class UpdateInventoryItemActivity extends AppCompatActivity {

    private EditText itemNameInput;
    private EditText itemDescriptionInput;
    private EditText itemQuantityInput;
    private Button updateItemButton;
    private DatabaseHelper dbHelper;
    private int itemId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_inventory_item);

        itemNameInput = findViewById(R.id.item_name_input);
        itemDescriptionInput = findViewById(R.id.item_description_input);
        itemQuantityInput = findViewById(R.id.item_quantity_input);
        updateItemButton = findViewById(R.id.update_item_button);
        dbHelper = new DatabaseHelper(this);

        itemId = getIntent().getIntExtra("ITEM_ID", -1);
        populateFields(itemId);

        updateItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateItem();
            }
        });
    }

    private void populateFields(int itemId) {
        InventoryItem item = dbHelper.getItem(itemId);
        if (item != null) {
            itemNameInput.setText(item.getTitle());
            itemDescriptionInput.setText(item.getDescription());
            itemQuantityInput.setText(String.valueOf(item.getQuantity()));
        }
    }

    private void updateItem() {
        String itemName = itemNameInput.getText().toString().trim();
        String itemDescription = itemDescriptionInput.getText().toString().trim();
        int itemQuantity = Integer.parseInt(itemQuantityInput.getText().toString().trim());

        boolean isUpdated = dbHelper.updateItem(itemId, itemName, itemQuantity, itemDescription);

        if (isUpdated) {
            Intent intent = new Intent(this, DataDisplayActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Error updating item", Toast.LENGTH_SHORT).show();
        }
    }
}