package com.example.inventoryviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.inventoryviewapp.helpers.DatabaseHelper;

public class AddInventoryItemActivity extends AppCompatActivity {

    private EditText itemNameInput;
    private EditText itemDescriptionInput;
    private EditText itemQuantityInput;
    private Button addItemButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_inventory_item);

        itemNameInput = findViewById(R.id.item_name_input);
        itemDescriptionInput = findViewById(R.id.item_description_input);
        itemQuantityInput = findViewById(R.id.item_quantity_input);
        addItemButton = findViewById(R.id.add_item_button);
        dbHelper = new DatabaseHelper(this);

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });
    }

    private void addItem() {
        String itemName = itemNameInput.getText().toString().trim();
        String itemDescription = itemDescriptionInput.getText().toString().trim();
        int itemQuantity = Integer.parseInt(itemQuantityInput.getText().toString().trim());

        dbHelper.addItem(itemName, itemQuantity, itemDescription);

        Intent intent = new Intent(this, DataDisplayActivity.class);
        startActivity(intent);
    }
}